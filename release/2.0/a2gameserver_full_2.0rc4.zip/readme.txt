1) Install 1.5 JDK (for compiling sources) or JRE (for executing only) from java.sun.com.
  DO NOT USE 1.4 -- IT WILL NOT WORK
2) make sure the java bin directory is part of your path
3) On the apple, type IN#2 (and return) from the basic prompt and leave it alone. (if using a //c, type ctrl-a and press the i key to see what is sent to the apple)
4) from the directory containing the dist and lib directories of a2gameserver, try:
WINDOWS:
java -Djava.library.path=lib -cp lib;lib/RXTXcomm.jar;dist/ags.jar ags.Main COM2 apple2
LINUX:
java -Djava.library.path=lib -cp lib:lib/RXTXcomm.jar:dist/ags.jar ags.Main /dev/ttyS0 apple2
MAC OSX:
java -Djava.library.path=lib -cp lib:lib/RXTXcomm.jar:dist/ags.jar ags.Main /dev/tty.usbserial apple2

This will attempt to open the specified com port (COM2, /dev/ttyS0, /dev/tty.usbserial) Within 30 seconds you should see either a menu on the apple
or an error on the PC stating some sort of problem.  Your serial port might be designated differently, so you might have to experiment in order for the program to find the port correctly.  Also, if you have an apple2c, use "apple2c" instead of "apple2" and make sure you're connected to the port to the right-side of the handle, which matches up to slot 2 logically.

Note: This program has a dependancy on the "rxtx" library, found at rxtx.org.
Please visit that site for libraries relevant to your system if you're not using a windows machine.
(and if you run this from a solaris machine you're stranger than I.  But let me know how it goes.)

To modify the init script, look in the lib/data directory and alter init.txt to your liking if something doesn't work for you (e.g. if your SSC is not in slot 2), read the script comments for more information.

Once you get the games menu on the apple ][, use A-Z to jump to the part of the list starting with that letter.  Use Left/Right or [ and ] to go half a screen up and down.  On a //e or //c, use up and down to move up and down one line.  On a legacy ][, use left/right to move up and down a line instead.  One you've found the game you want to play, press Return to load it.

brendan.robert (a) gmail.com
http://a2gameserver.sourceforge.net
http://brendan.robert.googlepages.com
http://www.brendandy.com