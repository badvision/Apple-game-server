/*
 * GameSearchWidget.java
 *
 * Created on May 19, 2006, 10:17 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package ags.ui.gameSelector;

import ags.ui.*;

/**
 * Search box to find games (not implemented yet)
 * @author blurry
 */
public class GameSearchWidget extends FrameBasedWidget {
    
    /**
     * Creates a new instance of GameSearchWidget
     */
    public GameSearchWidget(IApplication a) {
        super(a);
    }

    public void redrawInside() {
        
    }

    public boolean handleKeypress(byte b) {
        return false;
    }
}
