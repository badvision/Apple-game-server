import communication.TransferHost;
import gnu.io.CommDriver;
import gnu.io.CommPort;
import gnu.io.CommPortIdentifier;
import gnu.io.RXTXCommDriver;
import java.io.IOException;
import java.util.List;
import metadata.Game;
import metadata.Games;
import ui.GameSelectorApplication;
import ui.IVirtualScreen;
import ui.ScreenChange;
import ui.TextScreen40;
/*
 * Diskserver.java
 *
 * Created on May 17, 2006, 6:32 PM
 *
 * This is the main program.
 * Run this from the command line after putting the apple in input mode.
 * (e.g. type "in#2" and press return from the basic prompt)
 * @author blurry
 */
public class Diskserver {
    
    /**
     * List of single-file games
     */
    static List<Game> games;
    /**
     * port being used
     */
    static CommPort port;
    /**
     * Host utility to do all the work
     */
    static TransferHost host;
    /**
     * Creates a new instance of Diskserver
     */
    public Diskserver() {}

    /**
     * Initalize com port.  Make sure it is active.
     * @param portName name of port (e.g. COM2)
     * @throw IOException if port cannot be opened
     */
    private static void initPort(String portName) throws IOException {
        CommDriver driver = new RXTXCommDriver();
        driver.initialize();
        port = driver.getCommPort(portName, CommPortIdentifier.PORT_SERIAL);
        if (port != null) {
            System.out.println("Opened port: "+port.getName());
        } else
            throw new IOException("Port is not available!");
    }

    /**
     * This is the main body of the program
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        games = Games.readFromFile();
        System.out.println("Got "+games.size()+" games!");
        String portName = "COM2";
        if (args.length > 0) portName=args[0];
        
        try {
            initPort(portName);
            TransferHost host = new TransferHost(port);
            host.init();
//            host.loadGame(g);
//            host.startGame(g);
            IVirtualScreen screen = new TextScreen40();
            GameSelectorApplication app = new GameSelectorApplication(screen);
            app.setGames(games);
            app.redraw();
            host.sendRawData(screen.getBuffer(), 0x0400, 0, screen.getBuffer().length);
            while (app.gameSelected() == null) {
                byte key = host.getKey();
                if (key != 0) {
                    app.handleKeypress(key);
                    app.redraw();
                    List<ScreenChange> changes = app.getChanges();
                    byte[] buffer = app.getScreen().getBuffer();
                    for (ScreenChange s:changes)
                        host.sendRawData(buffer, 0x0400, s.start, s.length);
                }
            }
            host.startGame(app.gameSelected());
            System.out.println("Have fun playing "+app.gameSelected().getName()+"!");
        } catch (Throwable ex) {
            ex.printStackTrace();
        }
        shutdown();
    }
    
    /**
     * Close the port and whatever else needs to happen
     */
    public static void shutdown() {
        if (port != null) port.close();
    }
}