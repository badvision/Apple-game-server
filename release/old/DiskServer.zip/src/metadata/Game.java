package metadata;
/*
 * Game.java
 *
 * Created on May 17, 2006, 7:07 PM
 *
 * Bean representing information about a game
 * @author blurry
 */
public class Game {
    /**
     * Display-friendly name of game
     */
    private String name;
    /**
     * game file name
     */
    private String file;
    /**
     * hex type, as per Ciderpress
     */
    private int type;
    /**
     * Starting address
     */
    private int start;
    
    /** Creates a new instance of Game */
    public Game() {}

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getFile() {
        return file;
    }

    public void setFile(String file) {
        this.file = file;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public int getStart() {
        return start;
    }

    public void setStart(int start) {
        this.start = start;
    }
    
}