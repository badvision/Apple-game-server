package communication;
import gnu.io.CommPort;
import gnu.io.SerialPort;
import gnu.io.UnsupportedCommOperationException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
/*
 * GenericHost.java
 *
 * Created on May 18, 2006, 11:52 AM
 *
 * Generic com-based host, with methods to
 * make it easier to write rudimentary expectation-based logic
 * @author blurry
 */
public class GenericHost {
    
    /**
     * Active com port
     */
    SerialPort port = null;
    List buffer = null;
    /**
     * input stream for com port
     */
    InputStream in = null;
    /**
     * output stream for com port
     */
    OutputStream out = null;
    /**
     * Most recently set baud rate
     */
    int currentBaud = 0;
    /**
     * The familiar monitor prompt: *
     */
    public static final String MONITOR_PROMPT = "*";
    /**
     * The familiar applesoft prompt: ]
     */
    public static final String APPLESOFT_PROMPT = "]";
    public static char CANCEL_INPUT = 18; // CTRL-X cancels the input
    boolean expectEcho;
    
    /**
     * Creates a new instance of GenericHost
     * @param port Open com port ready to use
     */
    public GenericHost(CommPort port) {
        expectEcho = true;
//        expectEcho = false;
        this.port = (SerialPort) port;
        try {
            in = port.getInputStream();
            out = port.getOutputStream();
        } catch(IOException ex) {
            ex.printStackTrace();
        }
    }
    
    /**
     * Configure the port to the desired baud rate, 8-N-1
     * @param baudRate Baud rate (e.g. 300, 1200, ...)
     */
    public void setBaud(int baudRate) {
        try {
            port.setSerialPortParams(baudRate, 8, 1, 0);
            port.setFlowControlMode(0);
            currentBaud = baudRate;
        } catch(UnsupportedCommOperationException ex) {
            ex.printStackTrace();
        }
    }
    
    /**
     * Does this byte buffer contain the same values as the array of bytes?
     * @param bb buffer to check
     * @param data bytes to look for
     * @return true if bytes were found in the buffer
     */
    public static boolean bufferContains(ByteBuffer bb, byte data[]) {
        int d = 0;
        boolean match = false;
        for(int i = 0; i < bb.position() && d < data.length; i++)
            if(bb.get(i) == data[d]) {
            match = true;
            d++;
            } else {
            match = false;
            d = 0;
            }
        
        return match;
    }
    
    public void expectMonitor() throws IOException {
        if (expectEcho) expect(MONITOR_PROMPT, 5000, false);
        else wait(500);
    }
    
    public void expectApplesoft() throws IOException {
        if (expectEcho) expect(APPLESOFT_PROMPT, 5000, false);
        else wait(500);
    }
    
    /**
     * Expect a specific set of bytes to be sent in a given amount of time
     * @param data data expected
     * @param timeout max time to wait for data
     * @throws java.io.IOException if there is a timeout waiting for the data
     * @return true
     */
    public boolean expectBytes(byte data[], int timeout)
    throws IOException {
        ByteBuffer bb = ByteBuffer.allocate(Math.max(80,Math.max(in.available(),data.length * 2)));
        while(timeout > 0) {
            for(; in.available() == 0 && timeout > 0; timeout -= 5)
                wait(5);
            
            byte receivedData[] = getBytes();
            bb.put(receivedData);
            if(bufferContains(bb, data))
                return true;
        }
        if(bb.position() == 0)
            throw new IOException((new StringBuilder()).append("expected ").append(Arrays.toString(data)).append(" but timed out").toString());
        else
            throw new IOException((new StringBuilder()).append("Expected ").append(Arrays.toString(data)).append(" but got ").append(Arrays.toString(bb.array())).toString());
    }
    
    /**
     * Expect a specific string to be sent in a given amount of time
     * @param string data expected
     * @param timeout max time to wait for data
     * @param noConversion if true, string is treated as-is.  If false, expected data is converted to the high-order format that the apple sends back natively
     * @throws java.io.IOException if there is a timeout waiting for the data
     * @return
     */
    public boolean expect(String string, int timeout, boolean noConversion)
    throws IOException {
        String searchString = "";
        while(timeout > 0) {
            for(; in.available() == 0 && timeout > 0; timeout -= 10)
                wait(10);
            
            String receivedString = getString();
            if(!noConversion)
                receivedString = convertFromAppleText(receivedString);
            searchString = (new StringBuilder()).append(searchString).append(receivedString).toString();
            if(searchString.contains(string))
                return true;
        }
        if(searchString.equals(""))
            throw new IOException((new StringBuilder()).append("expected ").append(string).append(" but timed out").toString());
        else
            throw new IOException((new StringBuilder()).append("Expected ").append(string).append(" but got ").append(searchString).toString());
    }
    
    /**
     * Get all avail. com input data as a string
     * @throws java.io.IOException if there is a problem with the port
     * @return string of data
     */
    public String getString()
    throws IOException {
        if(in.available() == 0) {
            return "";
        } else {
            byte data[] = new byte[in.available()];
            in.read(data);
            return new String(data);
        }
    }
    
    /**
     * Get all avail. com input data as an array of bytes
     * @throws java.io.IOException if there is a problem with the port
     * @return data
     */
    public byte[] getBytes()
    throws IOException {
        byte data[] = new byte[in.available()];
        in.read(data);
        return data;
    }
    
    public void writeParanoid(String s) throws IOException {
        byte bytes[] = s.getBytes();
        byte[] expect = new byte[1];
        int errors = 0;
        for (int i=0; i < bytes.length && errors < 2; i++) {
            //System.out.println(i+"="+bytes[i]);
            try {
                out.write(bytes, i, 1);
                out.flush();
                if (bytes[i] >= 32 && expectEcho) {
                    expect(s.substring(i,i+1), 500, false);
                } else {
                    wait(5);
                }
                errors=0;
            } catch (IOException ex) {
                System.out.println("Failure writing line, retrying...");
                out.write(CANCEL_INPUT);      // control-x
                out.flush();
                i=-1;
                errors++;
//                ex.printStackTrace();
            }
        }
        if (errors >= 2) throw new IOException("Cannot write "+s);
    }
    
    /**
     * write a string out and sleep a little to let the buffer empty out
     * @param s String to write out
     */
    public void write(String s) throws IOException {
        byte bytes[] = s.getBytes();
        int blockSize = (currentBaud == 300 ? 80 : 2);
//            if(currentBaud == 300) waitTime += 500;
        for (int i=0; i < bytes.length; i+=blockSize) {
            int toGo = Math.min(blockSize, bytes.length - i);
            int waitTime = Math.max(10, (toGo * 10000) / currentBaud);
            Date d1 = new Date();
            out.write(bytes, i, toGo);
            Date d2 = new Date();
            int diff = (int)(d2.getTime() - d1.getTime());
            if(diff < waitTime) wait(waitTime - diff);
        }
    }
    
    /**
     * Given a file name, the contents of that file are sent verbatim to the apple.
     * After every line, the monitor prompt (*) is expected in order to continue.
     * @param executeHexFile name of file
     * @throws java.io.IOException if the file or com port cannot be accessed
     */
    public void enterHexProgram(String executeHexFile)
    throws IOException {
        String driverData = getFileAsString(executeHexFile);
        String lines[] = driverData.split("\n");
        String searchForLabel = null;
        String errorLabel = null;
        for(int i = 0; i < lines.length; i++) {
            boolean fatalError = false;
            String printLine = lines[i] + "\r";
//            System.out.println(printLine);
            if (searchForLabel != null) {
                if (lines[i].toLowerCase().equals(":"+searchForLabel.toLowerCase())) {
                    System.out.println("Skipping to label "+searchForLabel);
                    searchForLabel = null;
                }
                continue;
            }
            try {
                if (lines[i].startsWith(";")) continue;
                else if (lines[i].startsWith("!")) {
                    String[] command = printLine.substring(1).toLowerCase().split("\\s");
                    String cmd = command[0];
                    if (cmd.equals("goto")) {
                        searchForLabel = command[1];
                    } else if (cmd.equals("onerror")) {
                        errorLabel = command[1];
                    } else if (cmd.equals("baud")) {
                        int baud = Integer.parseInt(command[1]);
                        setBaud(baud);
                    } else if (cmd.equals("error")) {
                        fatalError = true;
                        throw new IOException(printLine.substring(1));
                    } else if (cmd.equals("wait")) {
                        int waitTime = Integer.parseInt(command[1]);
                        wait(waitTime);
                    } else if (cmd.equals("expect")) {
                        String v = command[1].toLowerCase();
                        boolean val = v.equals("true") || v.equals("on") || v.equals("1");
                        expectEcho = val;
                        System.out.println("Expect echo: "+String.valueOf(val));
                    } else {
                        System.out.println("Unknown command: "+command[0]);
                    }
                } else if (lines[i].startsWith(MONITOR_PROMPT)) {
                    writeParanoid(printLine.substring(1));
                    expectMonitor();
                } else if (lines[i].startsWith(APPLESOFT_PROMPT)) {
                    writeParanoid(printLine.substring(1));
                    expectApplesoft();
                } else if (lines[i].startsWith("~")) {
                    write(printLine.substring(1));
                } else if (lines[i].startsWith("'")) {
                    System.out.println(printLine.substring(1));
                } else if (lines[i].startsWith("\"")) {
                    writeParanoid("480:"+asAppleScreenHex(printLine.substring(1))+"\r");
                    expectMonitor();
                } else {
                    writeParanoid(printLine);
                }
            } catch (NumberFormatException ex) {
                if (fatalError) throw ex;
                ex.printStackTrace();
                System.out.println("You should check the script for bad numerical information (e.g. baud rate settings)");
                searchForLabel = errorLabel;
                errorLabel = null;
            } catch (IOException ex) {
                System.out.println("error in script, line "+(i+1)+":"+ex.getMessage());
                if (errorLabel == null || fatalError) throw ex;
                searchForLabel = errorLabel;
                errorLabel = null;
            }
        }
    }
    
    /**
     * Strip off apple high-order text
     * @param in text to strip
     * @return normalized ascii text (hopefully)
     */
    public static String convertFromAppleText(String in) {
        byte string[] = in.getBytes();
        StringBuffer out = new StringBuffer();
        for(int i = 0; i < in.length(); i++)
            out.append(new String(new byte[] {
                (byte)(string[i] & 0x7f)
            }));
        
        return out.toString();
    }
    
    /**
     * Convert a string of data to hexidecimal equivilants.  Useful for writing text directly to the screen.
     * @param in text
     * @return string of hex digits ready to be typed to the apple
     */
    public String asAppleScreenHex(String in) {
        StringBuffer out = new StringBuffer();
        for(int i = 0; i < in.length(); i++) {
            char c = in.charAt(i);
            if (c >= ' ') out.append(Integer.toHexString(c | 0x80)).append(' ');
        }
        
        return out.toString();
    }
    
    /**
     * Given an int, break it down to a little-endian word (byte array format)
     * @param i int to convert
     * @return little endian byte array
     */
    public static byte[] getWord(int i) {
        byte word[] = new byte[2];
        word[0] = (byte)(i % 256);
        word[1] = (byte)(i / 256);
        return word;
    }
    
    /**
     * Open a file and get its contents as one big string
     * @param file name of file to open
     * @return The file contents as a string
     */
    public static String getFileAsString(String file) {
        InputStream stream = GenericHost.class.getResourceAsStream(file);
        StringBuffer data = new StringBuffer();
        byte buf[] = new byte[256];
        int read = 0;
        try {
            while((read = stream.read(buf)) > 0) {
                String s = new String(buf, 0, read);
                data.append(s);
            }
        } catch(IOException ex) {
            ex.printStackTrace();
        }
        return data.toString();
    }
    
    /**
     * Open a file and get its contents as one big byte array
     * @param file name of file to open
     * @throws java.io.IOException if the file or com port cannot be accessed
     * @return byte array containing file's contents
     */
    public static byte[] getFileAsBytes(String file)
    throws IOException {
        InputStream stream = GenericHost.class.getResourceAsStream(file);
        int size = stream.available();
        ByteBuffer bb = ByteBuffer.allocate(size);
        byte buf[] = new byte[256];
        int read = 0;
        try {
            while((read = stream.read(buf)) > 0)
                bb.put(buf, 0, read);
        } catch(IOException ex) {
            ex.printStackTrace();
        }
        return bb.array();
    }
    
    /**
     * Sleep the current thread for a little while
     * @param time time in ms to wait
     */
    public static void wait(int time) {
        try {
            Thread.sleep(time);
        } catch(InterruptedException ex) {
            ex.printStackTrace();
        }
    }
}