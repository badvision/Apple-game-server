/*
 * ScreenChange.java
 *
 * Created on May 19, 2006, 8:34 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package ui;

/**
 *
 * @author Administrator
 */
public class ScreenChange {
    public int start;
    public int length;
}
