/*
 * InfoBarWidget.java
 *
 * Created on May 19, 2006, 10:16 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package ui;

/**
 *
 * @author Administrator
 */
public class InfoBarWidget extends IWidget {
    
    /** Creates a new instance of InfoBarWidget */
    public InfoBarWidget(IApplication a) {
        super(a);
    }

    public boolean handleKeypress(byte b) {
        return false;
    }

    public void redraw() {
    }
    
}
