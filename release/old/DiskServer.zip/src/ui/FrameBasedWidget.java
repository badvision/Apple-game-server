/*
 * FrameBasedWidget.java
 *
 * Created on May 19, 2006, 10:03 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package ui;

/**
 *
 * @author Administrator
 */
public abstract class FrameBasedWidget extends IWidget {
    
    public FrameBasedWidget(IApplication a) {
        super(a);
    }
    
    public void redraw() {
        app.getScreen().drawBorder(getX(), getY(), getX()+getXSize()-1, getY()+getYSize()-1, !isActive());
        app.getScreen().drawBox(getX(), getY(), getX()+getXSize()-1, getY()+getYSize()-1, false);
        redrawInside();
    }
    
    abstract public void redrawInside();
}
