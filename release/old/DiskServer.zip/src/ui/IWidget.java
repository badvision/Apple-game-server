/*
 * IWidget.java
 *
 * Created on May 19, 2006, 5:37 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package ui;

/**
 *
 * @author Administrator
 */
public abstract class IWidget {
    protected IApplication app;
    private boolean active;
    private int x;
    private int y;
    private int xSize;
    private int ySize;
    
    public IWidget(IApplication a) {
        app=a;
    }
    
    public void moveToTop() {
        app.moveToTop(this);
    }

    public boolean isActive() {
        return (this.active);
    }
    public void setActive(boolean active) {
        this.active = active;
    }
    
    public void destroy() {
        app.removeWidget(this);
    }
    
    abstract public boolean handleKeypress(byte b);
    abstract public void redraw();

    public int getX() {
        return x;
    }

    public void setX(int x) {
        this.x = x;
    }

    public int getY() {
        return y;
    }

    public void setY(int y) {
        this.y = y;
    }

    public int getXSize() {
        return xSize;
    }

    public void setXSize(int xSize) {
        this.xSize = xSize;
    }

    public int getYSize() {
        return ySize;
    }

    public void setYSize(int ySize) {
        this.ySize = ySize;
    }
}