/*
 * IApplication.java
 *
 * Created on May 19, 2006, 5:36 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package ui;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Administrator
 */
public abstract class IApplication {
    static final int MIN_CHANGE_DISTANCE = 40;
    protected List<IWidget> widgets;
    protected List<IWidget> visible;
    private IVirtualScreen screen;
    protected int currentWidget = -1;
    protected byte[] lastScreen;
    
    /**
     * Creates a new instance of IApplication
     */
    public IApplication(IVirtualScreen s) {
        widgets = new ArrayList<IWidget>();
        visible = new ArrayList<IWidget>();
        setScreen(s);
        copyScreen();
        init();
    }
    
    public void redraw() {
        getScreen().clear();
        for (IWidget widget:widgets) widget.redraw();
    }
    
    public void activate(IWidget w) {
        if (visible.isEmpty()) return;
        visible.get(visible.size()-1).setActive(false);
        w.setActive(true);
        w.moveToTop();
        currentWidget = widgets.indexOf(w);
        redraw();
    }
    
    public void addWidget(IWidget w) {
        widgets.add(w);
        visible.add(w);
        redraw();
    }

    public void moveToTop(IWidget w) {
        visible.remove(w);
        visible.add(w);
        if (currentWidget >= 0) {
            widgets.get(currentWidget).setActive(false);
        }
        currentWidget = widgets.indexOf(w);
        w.setActive(true);
        redraw();
    }
    
    public void removeWidget(IWidget w) {
        widgets.remove(w);
        visible.remove(w);
        if (currentWidget >= widgets.size()) currentWidget = widgets.size()-1;
        if (currentWidget >= 0) activate(widgets.get(currentWidget));
        redraw();
    }
    
    public void handleKeypress(byte b) {
        if (handleGlobalKeypress(b)) return;        
        if (currentWidget >= 0 && widgets.get(currentWidget).handleKeypress(b)) return;
        handleInvalidKeypress(b);
    }
    
    public List<ScreenChange> getChanges() {
        List<ScreenChange> out = new ArrayList<ScreenChange>();
        byte[] currentScreen = getScreen().getBuffer();
        int startChange = -1;
        int distFromLastChange = -1;
        for (int i=0; i < currentScreen.length; i++) {
            if (currentScreen[i] != lastScreen[i]) {
                if (startChange == -1) startChange = i;
                distFromLastChange = 0;
            } else {
                distFromLastChange++;
                if (distFromLastChange > MIN_CHANGE_DISTANCE && startChange >= 0) {
                    ScreenChange c = new ScreenChange();
                    c.start = startChange;
                    c.length = i-distFromLastChange-startChange + 1;
                    startChange = -1;
                    distFromLastChange = -1;
                    out.add(c);
                }
            }
        }
        if (startChange >= 0) {
            ScreenChange c = new ScreenChange();
            c.start = startChange;
            c.length = currentScreen.length - startChange;
            out.add(c);
        }
        copyScreen();
        return out;
    }
    
    private void copyScreen() {
        byte[] s = getScreen().getBuffer();
        lastScreen = new byte[s.length];
        for (int i=0; i < s.length; i++) lastScreen[i]=s[i];
    }
    
    abstract protected void init();
    abstract protected boolean handleGlobalKeypress(byte b);
    abstract protected boolean handleInvalidKeypress(byte b);

    public IVirtualScreen getScreen() {
        return screen;
    }

    public void setScreen(IVirtualScreen screen) {
        this.screen = screen;
    }
}