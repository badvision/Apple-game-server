/*
 * Keyboard.java
 *
 * Created on May 20, 2006, 2:14 AM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package ui;

/**
 *
 * @author Administrator
 */
public class Keyboard {
    
    static final byte KEY_UP = 11;
    static final byte KEY_DOWN = 10;
    static final byte KEY_LEFT = 8;
    static final byte KEY_RIGHT = 21;
    static final byte KEY_RETURN = 13;
    static final byte KEY_ESCAPE = 27;
    static final byte KEY_DELETE = 8;
    
    /** Creates a new instance of Keyboard */
    private Keyboard() {}
    
}
