package ui;
import java.awt.Image;
/*
 * IVirtualScreen.java
 *
 * Created on May 19, 2006, 3:20 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

/**
 *
 * @author Administrator
 */
public interface IVirtualScreen {
    public void clear();
    public void drawText(int x, int y, String text, boolean invert);
    public void drawBorder(int x1, int y1, int x2, int y2, boolean invert);
    public void drawBox(int x1, int y1, int x2, int y2, boolean invert);
    public void drawCursor(int x, int y);
    public void drawImage(int x, int y, int x1, int y1, Image i);
    public byte[] getBuffer();
}
