/*
 * GameSelectorApplication.java
 *
 * Created on May 19, 2006, 10:01 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package ui;

import java.util.List;
import metadata.Game;

/**
 *
 * @author Administrator
 */
public class GameSelectorApplication extends IApplication  {
    public GameSelectorApplication(IVirtualScreen s) {
        super(s);
    }
    
    InfoBarWidget infoBar;
    GameSearchWidget search;
    GameResultsWidget results;
    
    /** Creates a new instance of GameSelectorApplication */
//    public GameSelectorApplication {}
    protected void init() {
        infoBar = new InfoBarWidget(this);
        search = new GameSearchWidget(this);
        results = new GameResultsWidget(this);
        results.setX(1);
        results.setXSize(38);
        results.setY(1);
        results.setYSize(22);
//        addWidget(infoBar);
//        addWidget(search);
        addWidget(results);
        moveToTop(results);
    }

    protected boolean handleGlobalKeypress(byte b) {
        return false;
    }

    protected boolean handleInvalidKeypress(byte b) {
        return false;
    }
    
    public void setGames(List<Game> games) {
        results.results = games;
    }
    public Game gameSelected() {
        return results.selection;
    }
}