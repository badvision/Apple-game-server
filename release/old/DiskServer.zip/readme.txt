1) Install 1.5 JDK (for compiling sources) or JRE (for executing only) from java.sun.com.
  DO NOT USE 1.4 -- IT WILL NOT WORK
2) make sure the java bin directory is part of your path
3) On the apple, type IN#2 (and return) from the basic prompt and leave it alone.
4) from this directory, try:
java -Djava.library.path=lib -cp lib;lib/RXTXcomm.jar;dist/DiskServer.jar Diskserver COM2

This will attempt to open COM2.  Within 30 seconds you should see either a menu on the apple
or an error on the PC stating some sort of problem.  Linux is similar except replace the semi-colons
with colons and use the appropriate device under /dev for your serial port of choosing.

Note: This program has a dependancy on the "rxtx" library, found at rxtx.org.
Please visit that site for libraries relevant to your system if you're not using a windows machine.
(and if you run this from a solaris machine you're stranger than I.  But let me know how it goes.)

To modify the init script, look in the lib/data directory and alter init.txt to your liking.

brendan.robert (a) gmail.com
http://brendan.robert.googlepages.com
http://www.brendandy.com