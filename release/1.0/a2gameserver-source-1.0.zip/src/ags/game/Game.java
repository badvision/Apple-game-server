package ags.game;
/*
 * Game.java
 *
 * Created on May 17, 2006, 7:07 PM
 *
 * Bean representing information about a game
 * @author blurry
 */
/**
 * Java bean representative of a game
 */
public class Game {
    /**
     * Display-friendly name of game
     */
    private String name;
    /**
     * game file name
     */
    private String file;
    /**
     * hex type, as per Ciderpress
     */
    private int type;
    /**
     * Starting address
     */
    private int start;
    
    /** Creates a new instance of Game */
    public Game() {}

    /**
     * Getter for name property
     * @return name property
     */
    public String getName() {
        return name;
    }

    /**
     * Setter for name property
     * @param name name property
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Getter for file path property
     * @return file path property
     */
    public String getFile() {
        return file;
    }

    /**
     * Setter for file path property
     * @param file file path property
     */
    public void setFile(String file) {
        this.file = file;
    }

    /**
     * Getter for file type property
     * @return file type property
     */
    public int getType() {
        return type;
    }

    /**
     * Setter for file type property
     * @param type file type property
     */
    public void setType(int type) {
        this.type = type;
    }

    /**
     * Getter for start address property
     * @return start address property
     */
    public int getStart() {
        return start;
    }

    /**
     * Setter for start address property
     * @param start start address property
     */
    public void setStart(int start) {
        this.start = start;
    }
    
}