/*
 * Palette16.java
 *
 * Created on June 23, 2006, 1:10 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package ags.ui.graphics;

import com.sun.org.apache.bcel.internal.classfile.JavaClass;
import java.awt.Color;

/**
 *
 * @author Administrator
 */
public class Palette16 extends Palette {
    
    protected void initPalette() {
        addColor(0, 0, 0);
        addColor(208, 0, 48);
        addColor(0, 0, 128);
        addColor(255, 0, 255);
        addColor(0, 128, 0);
        addColor(128, 128, 128);
        addColor(0, 0, 255);
        addColor(96, 160, 255);
        addColor(128, 80, 0);
        addColor(255, 128, 0);
        addColor(192, 192, 192);
        addColor(255, 144, 128);
        addColor(0, 255, 0);
        addColor(255, 255, 0);
        addColor(64, 255, 144);
        addColor(255, 255, 255);
    }
}